<?php
require_once __DIR__ . '/Vinyle.php';
echo vin();