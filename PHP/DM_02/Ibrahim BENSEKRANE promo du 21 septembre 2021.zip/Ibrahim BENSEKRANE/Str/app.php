<?php
// définitions des fonctions
function shuffleStr(string $str): string {
    return str_shuffle($str);
}
echo shuffleStr("Bonjour tout le monde !");
echo "<br>";
// ...
function countLetters(string $str): int {
    return str_word_count($str);
}
echo countLetters("Bonjour tout le monde !");
echo "<br>";
// ...
function isLetter(string $str, string $letter): int|bool {
    return strpos($str, $letter);
}
echo isLetter("Bonjour tout le monde !", "t");
echo "<br>";