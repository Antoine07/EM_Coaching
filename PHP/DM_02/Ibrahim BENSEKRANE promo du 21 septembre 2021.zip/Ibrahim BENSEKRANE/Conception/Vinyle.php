<?php
include __DIR__ . '/Disque.php';

function vin($var = 'null') {
    return $var;
}