<?php
$file = "./Data/titanic.csv";
// Ouvre une ressource avec l'adresse du fichier en lecture seule.

function getAliveNum($file) {
    $handle = fopen($file, "r");

    $survivant = 0;
    while ($data = fgetcsv($handle, 1000, ",")) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $survivant = $survivant +  $data[1];
        }
    }
    return $survivant;
}
function getAlive(string $sex, $file) {
    $handle = fopen($file, "r");

    $humanState = 0;
    while ($data = fgetcsv($handle, 1000, ",")) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if ($data[4] === $sex) {
                if ($data[1] == 1) {
                    $humanState = $humanState +  1;
                }
            }
        }
    }
    return $humanState;
}


function getDead(string $sex, $file) {
    $handle = fopen($file, "r");

    $humanState = 0;
    while ($data = fgetcsv($handle, 1000, ",")) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if ($data[4] === $sex) {
                if ($data[1] == 0) {
                    $humanState = $humanState +  1;
                }
            }
        }
    }
    return $humanState;
}
echo "<br>";
echo 'nombre de personnes vivantes :' . getAliveNum($file);
echo "<br>";
echo 'nombre de mâles vivants est:' . getAlive('male', $file);
echo "<br>";
echo 'nombre de femelles vivants est :' . getAlive('female', $file);
echo "<br>";
echo 'nombre de mâles morts :' . getDead('male', $file);
echo "<br>";
echo 'nombre de femelles mortes ' . getDead('female', $file);
